<?php

define('ENABLE_SHELL_PLUGIN', true);
